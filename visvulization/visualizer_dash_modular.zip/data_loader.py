
import os
from constants import FILTER_NAME
from utils import extract_participant_id

def load_csv_files(folder_path, merged_labels_folder):
    csv_files_hr = [f for f in os.listdir(folder_path) if f.endswith('.csv') and FILTER_NAME in f]
    csv_files_belt = [f for f in os.listdir(folder_path) if f.endswith('.csv') and "belt" in f]
    merge_labels_hr = [f for f in os.listdir(merged_labels_folder) if f.endswith('.csv') and FILTER_NAME in f]

    csv_files_sorted = sorted(csv_files_hr, key=extract_participant_id)

    return {
        'heart_files': csv_files_hr,
        'belt_files': csv_files_belt,
        'label_files': merge_labels_hr,
        'sorted_files': csv_files_sorted
    }
