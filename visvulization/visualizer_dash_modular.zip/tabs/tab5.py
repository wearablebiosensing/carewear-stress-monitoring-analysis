
from dash import html

def render():
    return html.Div([
        html.H3("This is Tab 5")
    ])
