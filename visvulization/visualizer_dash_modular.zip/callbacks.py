
from dash import Input, Output, html
from tabs import tab1, tab2, tab3, tab4, tab5

def register_callbacks(app):
    @app.callback(
        Output('tabs-content', 'children'),
        [Input('url', 'pathname')]
    )
    def display_tab(pathname):
        if pathname == '/tab1':
            return tab1.render()
        elif pathname == '/tab2':
            return tab2.render()
        elif pathname == '/tab3':
            return tab3.render()
        elif pathname == '/tab4':
            return tab4.render()
        elif pathname == '/tab5':
            return tab5.render()
        return html.Div("Welcome! Select a tab.")
