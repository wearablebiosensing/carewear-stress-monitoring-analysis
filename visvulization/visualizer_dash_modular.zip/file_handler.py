
import tkinter as tk
from tkinter import filedialog

def select_folders():
    root = tk.Tk()
    root.withdraw()
    folder1 = filedialog.askdirectory(title="Select Concat_File folder")
    folder2 = filedialog.askdirectory(title="Select the merged_lables folder")
    return folder1, folder2
