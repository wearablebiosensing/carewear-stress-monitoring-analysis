
import re

def extract_participant_id(file_name):
    match = re.search(r'_P(\d+)', file_name)
    return int(match.group(1)) if match else float('inf')
