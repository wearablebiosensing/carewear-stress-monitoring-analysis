
from dash import html, dcc

def create_layout():
    return html.Div([
        html.Div([
            html.Nav([
                dcc.Link(f'Tab {i}', href=f'/tab{i}', style={
                    'display': 'block', 'padding': '10px', 'background-color': '#d3d3d3'
                }) for i in range(1, 6)
            ], style={'width': '200px', 'height': '100vh', 'position': 'fixed', 'background-color': '#f0f0f0'})
        ], style={'width': '200px'}),
        dcc.Location(id='url', refresh=False),
        html.Div([
            html.Div(id='tabs-content', style={'margin-left': '220px'})
        ], style={'display': 'inline-block', 'width': 'calc(100% - 220px)'})
    ])
